package com.example.sis3_task1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sis3Task1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
